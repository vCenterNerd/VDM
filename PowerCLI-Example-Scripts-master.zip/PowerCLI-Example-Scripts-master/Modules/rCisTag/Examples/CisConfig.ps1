﻿$cisServer = 'vcsa.my.domain'
$cisUser = 'administrator@vsphere.local'
$cisPswd = 'VMware1!'
